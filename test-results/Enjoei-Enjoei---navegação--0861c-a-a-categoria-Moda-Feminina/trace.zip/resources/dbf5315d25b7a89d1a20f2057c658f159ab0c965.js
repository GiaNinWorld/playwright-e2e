const DEFAULT = {
  icon: '/favicon-96x96.png',
  url: 'https://www.enjoei.com.br'
}

/**
 * The `notificationclick` listener must be defined before
 * loading the Firebase Cloud Messaging library scripts,
 * because of the `stopImmediatePropagation` event.
 *
 * Reference: https://github.com/firebase/quickstart-js/issues/102#issuecomment-278584863
 */
self.addEventListener('notificationclick', function(event) {
  event.notification.close()
  const url = getUrl(event.notification.data)

  event.waitUntil(clients.matchAll({
    type: 'window'
  }).then(clients.openWindow(url)))
})

self.addEventListener('push', (event) => {
  const payload = event.data.json()

  if (payload.from && payload.from !== CONFIG.messagingSenderId) return

  event.waitUntil(self.registration.showNotification(payload.notification.title, {
    body: payload.notification.body,
    image: payload.notification.image,
    icon: DEFAULT.icon,
    data: payload.data || {}
  }))

  event.stopImmediatePropagation()
})

function getUrl(notificationData) {
  const baseUrl = notificationData.url || DEFAULT.url
  const { utm_source, utm_medium, utm_campaign } = notificationData

  return includeQueryStringParams(baseUrl, { utm_source, utm_medium, utm_campaign })
}

function includeQueryStringParams(url, params = {}) {
  const baseUrl = addQueryStringSeparator(url)
  const normalizedParams = Object.keys(params).map(k => params[k] ? `${k}=${params[k]}` : null).filter(Boolean)

  return `${baseUrl}${normalizedParams.join('&')}`
}

function addQueryStringSeparator(url) {
  return url.indexOf('?') > -1 ? `${url}&` : `${url}?`
}

/**
 * Start Firebase Cloud Messaging service
 */
importScripts('https://www.gstatic.com/firebasejs/11.3.1/firebase-app-compat.js')
importScripts('https://www.gstatic.com/firebasejs/11.3.1/firebase-messaging-compat.js')

firebase.initializeApp(CONFIG)
if (firebase.messaging.isSupported()) {
  const messaging = firebase.messaging()
}
